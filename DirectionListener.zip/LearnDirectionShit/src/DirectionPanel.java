import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DirectionPanel extends JPanel
{
	private static final long serialVersionUID = 1L;
	public JLabel showDirectionLabel, myDirectionLabel;
	
	String up = "UP";
	String down  = "DOWN";
	String right = "RIGHT";
	String left = "LEFT";
	
	//CONSTRUCTOR: SETS UP THIS PANEL AND LOAD IMAGES
	public DirectionPanel()
	{
		addKeyListener (new DirectionListener());
		
		showDirectionLabel = new JLabel ("What is the direction?");
		myDirectionLabel = new JLabel ("nooo direction god damn it!");
		add (showDirectionLabel);
		add (myDirectionLabel);
		setPreferredSize(new Dimension (500,500));
		setBackground(Color.pink);
		setFocusable(true);//FORGOT TO WRITE THIS FFS 
						   //IT TOOK 3 HOURS TO SEE!!!
	}


	//REPRESENTS THE LISTENER FOR KEYBOARD ACTIVITY
	private class DirectionListener implements KeyListener
	{
		
		@Override
		public void keyPressed(KeyEvent e) {
			switch (e.getKeyCode())
			{
			case KeyEvent.VK_UP:
				myDirectionLabel.setText (up);
				break;
			case KeyEvent.VK_DOWN:
				myDirectionLabel.setText(down);
				break;
			case KeyEvent.VK_LEFT:
				myDirectionLabel.setText(left);
				break;
			case KeyEvent.VK_RIGHT:
				myDirectionLabel.setText(right);
				break;
			}
			repaint();
			
		}
		//PROVIDE EMPTY DEFINITIONS FOR UNUSED EVENT METHODS
		@Override
		public void keyReleased(KeyEvent e) {}

		@Override
		public void keyTyped(KeyEvent e) {}
		
	}
	
	public static void main (String [] args)
	{
		JFrame frame = new JFrame ("KEY! FFS!!!");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		DirectionPanel mypanel = new DirectionPanel();
		frame.getContentPane().add(mypanel);
		frame.pack();
		frame.setVisible(true);
	}
	
	

}
