import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * Created by Irma Chan on 6.5.2017.
 */
public class gamePlayPanel extends JPanel{

    private final int WIDTH=1000, HEIGHT=700;
    private gameLogic graph;
    public gamePlayPanel(){
        graph = new gameLogic();
        addKeyListener(new DirectionListener());
        setPreferredSize (new Dimension(WIDTH, HEIGHT));
        setBackground (Color.black);
        setFocusable(true);//FORGOT TO WRITE THIS FFS
        //IT TOOK 3 HOURS TO SEE!!!
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (ClassNotFoundException ex) {
                } catch (InstantiationException ex) {
                } catch (IllegalAccessException ex) {
                } catch (UnsupportedLookAndFeelException ex) {
                }

            }
        });
    }
    //REPRESENTS THE LISTENER FOR KEYBOARD ACTIVITY
    private class DirectionListener implements KeyListener
    {

        @Override
        public void keyPressed(KeyEvent e) {
            switch (e.getKeyCode())
            {
                case KeyEvent.VK_UP:
                    graph.turnRight();
                    break;
                case KeyEvent.VK_DOWN:
                    graph.turnLeft();
                    break;
                case KeyEvent.VK_LEFT:
                    graph.moveLeft();
                    break;
                case KeyEvent.VK_RIGHT:
                    graph.moveRight();
                    break;
            }
            repaint();

        }
        //PROVIDE EMPTY DEFINITIONS FOR UNUSED EVENT METHODS
        @Override
        public void keyReleased(KeyEvent e) {}

        @Override
        public void keyTyped(KeyEvent e) {}

    }

    public void paintComponent (Graphics page)
    {
        super.paintComponent (page);
        page.setColor (Color.pink);

        for (int i = 0; i < graph.getRowPixel(); i++) {
            for (int j = 0; j < graph.getColumnPixel()-2; j++) {
                if((graph.getGraph())[i][j]==true) {
                	
                	page.drawRect(500 + i * 40, j * 40, 40, 40);
                	page.fillRect(500 + i * 40, j * 40, 38, 38);
                    repaint();
                }
            }
        }

    }

}
