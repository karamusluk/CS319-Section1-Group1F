import javax.swing.Timer;
import java.awt.event.*;
import java.sql.Time;

/**
 * Created by Irma Chan on 6.5.2017.
 */
public class gameLogic {

    private Timer timer;
    private enum Letter { I, J, L, O, S, T, Z}
    private boolean[][] graph;
    private final int columnPixel = 24;
    private final int rowPixel = 20;
    private int delay;
    private Block currentFallingBlock;
    private boolean [][] pit;
    private int posX,posY;
    private boolean [][] currentFallingUnits;


    public gameLogic(){

        graph = new boolean[rowPixel][columnPixel];
        pit = new boolean[rowPixel][columnPixel];
        delay = 200;

        for (int i = 0; i < rowPixel; i++) {
            for (int j = 0; j <columnPixel ; j++) {
                if(i==0 ||  i == rowPixel-2)
                    graph[i][j] = true;
                else
                    graph[i][j] = false;
            }
        }

        for (int i = 0; i < rowPixel; i++) {
            for (int j = 0; j <columnPixel ; j++) {
                if(i==0 ||i == rowPixel-2)
                    pit[i][j] = true;
                else
                    pit[i][j] = false;
            }
        }
        posX=rowPixel/2;posY=0;
        currentFallingUnits = new boolean[4][4];
        currentFallingUnits = randomBlock();
        fall(currentFallingUnits);

        timer = new Timer(delay,new ReboundListener());
        timer.start();
    }

    private class ReboundListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            if(checkCollapse() == false)
                fall(currentFallingUnits);

            else if(checkCollapse()==true){
                for (int i = 0; i < rowPixel; i++) {
                    for (int j = 0; j <columnPixel ; j++) {
                        pit[i][j] = graph[i][j];
                    }
                }
                currentFallingUnits = new boolean[4][4];
                currentFallingUnits = randomBlock();
                posX=rowPixel/2;posY=0;
                fall(currentFallingUnits);

            }
        }
    }
    public void play(){

    }
    private void fall(boolean[][] units) {

        for (int i = 0; i < rowPixel; i++) {
                for (int j = 0; j < columnPixel; j++) {
                    graph[i][j] = pit[i][j];
                }
            }
        for (int i = 0; i <4 ; i++) {
            for (int j = 0; j < 4; j++) {
                if(i+posX+2<rowPixel && j+posY<columnPixel) {
                    if(units[i][j]==true) {
                        graph[i + posX][j + posY] = units[i][j];
                    }
                }
            }
        }
        posY = posY+1;
    }

    public void moveLeft(){
        timer.stop();
        if(posX>0) {

            for (int i = 0; i < rowPixel; i++) {
                for (int j = 0; j < columnPixel; j++) {
                    graph[i][j] = pit[i][j];
                }
            }


            posX = posX-1;
            fall(currentFallingUnits);
        }
        timer.start();

    }

    public void moveRight() {
        timer.stop();
        if(posX<rowPixel-6) {

            for (int i = 0; i < rowPixel; i++) {
                for (int j = 0; j < columnPixel; j++) {
                    graph[i][j] = pit[i][j];
                }
            }


            posX = posX+1;
            fall(currentFallingUnits);
        }
        timer.start();

    }

    //Random Letter generated here
    public Letter randomLetter(){
        int randomNo= (int)(Math.random()*6);
        if(randomNo == 0){
            return Letter.I;}
        else  if(randomNo == 1){
            return Letter.J;
        }
        else  if(randomNo == 2){
            return Letter.L;
        }
        else  if(randomNo == 3){
            return Letter.O;
        }
        else  if(randomNo == 4){
            return Letter.S;
        }
        else  if(randomNo == 5){
            return Letter.T;
        }
        else {
            return Letter.Z;
        }
    }

    public boolean[][] randomBlock(){
        Letter random=randomLetter();
        Block myBlock = new Block();
        boolean [][] r;
        if(random==Letter.L)
            r=  myBlock.shapeL();
        else if(random==Letter.J) {
            r = myBlock.shapeJ();
        }
        else if(random==Letter.I)
        {    r= (myBlock.shapeI());
             r = myBlock.turnLeft();
        }
        else if(random==Letter.Z)
            r= myBlock.shapeZ();
        else if(random==Letter.S)
            r= myBlock.shapeS();
        else if(random==Letter.O)
            r= myBlock.shapeO();
        else
            r= myBlock.shapeT();
        currentFallingBlock = myBlock;
        return r;
    }

    public boolean[][] getGraph(){
        return graph;
    }



    public boolean checkCollapse(){
        for (int i = 0; i <rowPixel ; i++) {
            if(pit[i][columnPixel-1]==true)
                endGame();

        }
        for (int i = 0; i < 4 ; i++) {
            for (int j = 0; j < 4 ; j++) {
                if(currentFallingUnits[i][j]==true )
                {
                    if(posY+j>=columnPixel-2)
                        return true;
                    else if( pit[posX+i][posY+j]==true && posX+i<rowPixel-1)
                        return true;

                }

            }
        }
        return false;
    }

    private void endGame() {
        //System.exit(0);
    }

    public int getRowPixel() {
        return rowPixel;
    }

    public int getColumnPixel() {
        return columnPixel;
    }

    public void setGraph(boolean[][] graph) {
        this.graph = graph;
    }

    public void pop(int rowNumber){

    }

    public boolean checkPop(){
        boolean status=false;
        return status;
    }

    public void turnRight(){

        timer.stop();
        if(posX>0) {

            for (int i = 0; i < rowPixel; i++) {
                for (int j = 0; j < columnPixel; j++) {
                    graph[i][j] = pit[i][j];
                }
            }

        }

        currentFallingUnits = new boolean[4][4];
        currentFallingUnits = (currentFallingBlock.turnRight());
        timer.setDelay(delay);

        fall(currentFallingUnits);
        timer.start();

    }
    public void turnLeft(){
        timer.stop();
        if(posX>0) {

            for (int i = 0; i < rowPixel; i++) {
                for (int j = 0; j < columnPixel; j++) {
                    graph[i][j] = pit[i][j];
                }
            }

        }

        currentFallingUnits = new boolean[4][4];
        currentFallingUnits = (currentFallingBlock.turnLeft());
        timer.setDelay(delay);

        fall(currentFallingUnits);
        timer.start();
    }

}
