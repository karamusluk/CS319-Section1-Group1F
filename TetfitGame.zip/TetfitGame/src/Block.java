/**
 * Created by Irma Chan on 6.5.2017.
 */
public class Block {

    public boolean[][] getLetterGrid() {
        return letterGrid;
    }

    private boolean[][] letterGrid;
    public Block(){
        letterGrid = new boolean [4][4];
        for(int i = 0 ; i<4; i++)
            for(int j = 0; j<4; j++)
                letterGrid [i][j]= false;
    }
    public boolean [][] turnRight() {

        //inner swap
        boolean temp = letterGrid[2][1];
        boolean temp2 = letterGrid[1][1];
        boolean temp3 = letterGrid[1][2];
        letterGrid[2][1]= letterGrid[2][2];
        letterGrid[1][1] = temp;
        letterGrid[1][2] = temp2;
        letterGrid[2][2] = temp3;

        //middle swap 1
        temp = letterGrid[2][0];
        temp2 = letterGrid[0][1];
        temp3 = letterGrid[1][3];
        letterGrid[2][0]= letterGrid[3][2];
        letterGrid[0][1] = temp;
        letterGrid[1][3] = temp2;
        letterGrid[3][2] = temp3;

        //middle swap 2
        temp = letterGrid[1][0];
        temp2 = letterGrid[0][2];
        temp3 = letterGrid[2][3];
        letterGrid[1][0]= letterGrid[3][1];
        letterGrid[0][2] = temp;
        letterGrid[2][3] = temp2;
        letterGrid[3][1] = temp3;


        //corner swap
        temp = letterGrid[0][0];
        temp2 = letterGrid[0][3];
        temp3 = letterGrid[3][3];
        letterGrid[0][0]= letterGrid[3][0];
        letterGrid[0][3] = temp;
        letterGrid[3][3] = temp2;
        letterGrid[3][0] = temp3;


        return letterGrid;
    }

    public boolean [][] turnLeft() {

        //inner swap
        boolean temp = letterGrid[2][2];
        boolean temp2 = letterGrid[1][2];
        boolean temp3 = letterGrid[1][1];
        letterGrid[2][2]= letterGrid[2][1];
        letterGrid[1][2] = temp;
        letterGrid[1][1] = temp2;
        letterGrid[2][1] = temp3;

        //middle swap 1
        temp = letterGrid[2][0];
        temp2 = letterGrid[3][2];
        temp3 = letterGrid[1][3];
        letterGrid[2][0] = letterGrid[0][1];
        letterGrid[3][2] = temp;
        letterGrid[1][3] = temp2;
        letterGrid[0][1] = temp3;

        //middle swap 2
        temp = letterGrid[1][0];
        temp2 = letterGrid[0][2];
        temp3 = letterGrid[2][3];
        letterGrid[2][3]= letterGrid[3][1];
        letterGrid[0][2] = temp3;
        letterGrid[1][0] = temp2;
        letterGrid[3][1] = temp;


        //corner swap
        temp = letterGrid[0][0];
        temp2 = letterGrid[0][3];
        temp3 = letterGrid[3][3];
        letterGrid[3][3]= letterGrid[3][0];
        letterGrid[0][3] = temp3;
        letterGrid[0][0] = temp2;
        letterGrid[3][0] = temp;


        return letterGrid;
    }
// I, J, L, O, T, S and Z
    public boolean[][] shapeI(){

        letterGrid[0][1]=true;
        letterGrid[1][1]=true;
        letterGrid[2][1]=true;
        letterGrid[3][1]=true;

        return letterGrid;
    }
    public boolean[][] shapeJ(){
        letterGrid[1][2]=true;
        letterGrid[2][2]=true;
        letterGrid[3][2]=true;
        letterGrid[3][1]=true;

        return letterGrid;
    }
    public boolean[][] shapeL(){
        letterGrid[1][1]=true;
        letterGrid[2][1]=true;
        letterGrid[3][1]=true;
        letterGrid[3][2]=true;

        return letterGrid;
    }
    public boolean[][] shapeO(){
        letterGrid[1][1]=true;
        letterGrid[1][2]=true;
        letterGrid[2][1]=true;
        letterGrid[2][2]=true;

        return letterGrid;
    }
    public boolean[][] shapeT(){
        letterGrid[1][1]=true;
        letterGrid[2][0]=true;
        letterGrid[2][1]=true;
        letterGrid[2][2]=true;

        return letterGrid;
    }
    public boolean[][] shapeS(){
        letterGrid[1][1]=true;
        letterGrid[1][2]=true;
        letterGrid[2][1]=true;
        letterGrid[2][0]=true;

        return letterGrid;
    }
    public boolean[][] shapeZ(){
        letterGrid[1][1]=true;
        letterGrid[1][2]=true;
        letterGrid[2][2]=true;
        letterGrid[2][3]=true;

        return letterGrid;
    }

}
