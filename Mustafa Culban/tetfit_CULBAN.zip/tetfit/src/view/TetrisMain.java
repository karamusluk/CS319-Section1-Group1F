
package view;

//to invoke on the time
import java.awt.EventQueue;


public class TetrisMain {

  //contstructor
  public TetrisMain(){
	  EventQueue.invokeLater(new Runnable() {
	      @Override
	      public void run() {
	        new TetrisGUI();
	      } 
	    });
  }
  //whether we want to run it directly. Yet on this implementation it is not necessary
  public static void main( String[] the_args) {
	  new TetrisMain();
  }

}
