
package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.Observable;
import java.util.Observer;

import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.Sequence;
import javax.sound.midi.Sequencer;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.Timer;

import model.Board;

public class TetrisGUI extends JFrame implements Observer {

  private static final long serialVersionUID = 444444444;

  
  //timer for whole game when it started
  protected Timer gameTimer = new Timer(0, null);
  
  //is game paused?			   is game over?
  protected boolean isGamePaused, isGameOver;
   
  //player cleaned this may line
  protected int lineCleanedSoFar;
  
  //constructor. Such a massive constructor .
  Sequencer sequencer = null;
  
  public TetrisGUI() {
    super("TETFIT v1.0");
    super.setLayout(new FlowLayout());
    //a board
    Board board = new Board();
    board.newGame(10, 20, null);
    // a display unit
    BoardDisplay boardDisplay = new BoardDisplay();
    // for next piece of course
    NextPieceDisplay nextPieceDisplaay = new NextPieceDisplay();
    // how is the game going
    InfoDisplay playerInfo = new InfoDisplay();
    
    gameTimer.setDelay(1000);
    gameTimer.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        board.moveDown();
      }
    });
    
    
    board.addObserver(boardDisplay);
    board.addObserver(nextPieceDisplaay);
    board.addObserver(this);
    
    super.add(boardDisplay, BorderLayout.CENTER);
    super.add(nextPieceDisplaay, BorderLayout.EAST);

    super.setSize(130, 300);
    
    super.getContentPane().setBackground(Color.BLACK);
    super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    gameTimer.start();
    super.setResizable(true);
    
    boardDisplay.addKeyListener(new TetrisKeyListener(board, boardDisplay));
    
    createMenuBar(boardDisplay, board, playerInfo);
    
    super.add(playerInfo);
    board.addObserver(playerInfo);
    super.pack();
    super.setVisible(true);
  }
  
  
  
  // menu for the game which will be on the upper part of the game
  private void createMenuBar( BoardDisplay the_board_display,  Board the_board,
                              InfoDisplay the_info_display) {
     JMenuBar menubar = new JMenuBar();
     JMenu file = new JMenu("TETFIT");
     JMenuItem newgame = new JMenuItem("Newe Game");
     JMenuItem endgame = new JMenuItem("Finish?");
     JMenu help = new JMenu("Information");
     JMenuItem controls = new JMenuItem("Controls");
     JMenuItem credits = new JMenuItem("Credits");
     JMenuItem backToMenu = new JMenuItem("Back To Menu");
    
    newgame.addActionListener(new ActionListener() {
      public void actionPerformed( ActionEvent the_event) {
        gameTimer.stop();
        the_board.newGame(10, 20, null);
        lineCleanedSoFar = 0;
        the_info_display.reset();
        gameTimer.setDelay(1000);
        if (the_board_display.isPaused()) {
          the_board_display.setPause();
        }
        if (the_board_display.isGameOver()) {
          the_board_display.setGameOver();
        }
        isGameOver = false;
        gameTimer.start();
      }
    });
    
    endgame.addActionListener(new ActionListener() {
      public void actionPerformed( ActionEvent the_event) {
        gameTimer.stop();
        the_board_display.setGameOver();
        if (the_board_display.isPaused()) {
          the_board_display.setPause();
        }
        isGameOver = true;
      }
    });
    
    controls.addActionListener(new ActionListener() {
      public void actionPerformed( ActionEvent the_event) {
        pause(the_board_display);
        printControls();
        pause(the_board_display);
        
      }
    });
    
    credits.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			pause(the_board_display);
			credit();
			pause(the_board_display);
		}
	});
    
    backToMenu.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
			
			int selectedOption = JOptionPane.showConfirmDialog(null, 
	                  "U wanno really close this superb game?", 
	                  "the chose your side", 
	                  JOptionPane.YES_NO_OPTION); 
	    	  if (selectedOption == JOptionPane.YES_OPTION) {
	    		
	    		gameTimer.stop();
	  	        the_board_display.setGameOver();
	  	        if (the_board_display.isPaused()) {
	  	          the_board_display.setPause();
	  	        }
	  	        isGameOver = true;
	  	        setVisible(false);
	  	        dispose();
	  	        new GameMenu();
	    	  }
	    	  else{
	    		 
	    	  }
	    	  // TODO Auto-generated method stub
			
	        
		}
	});
    
    menubar.add(file);
    file.add(newgame);
    file.add(endgame);
    
    JMenu music = new JMenu("MIDI Musics");
    JRadioButtonMenuItem thirdAvenue = new JRadioButtonMenuItem("3rd Avenue");
    ButtonGroup group = new ButtonGroup();
    Sequence ThirdAvenue = null;
    
    try {
      
      ThirdAvenue = MidiSystem.getSequence(new File("3rdAvenue.mid"));
      sequencer = MidiSystem.getSequencer();
      sequencer.open();
      
    } catch ( IOException e) {
      System.err.println("IOException caught!");
    } catch ( InvalidMidiDataException e) {
      System.err.println("InvalidMidiDataException caugth!");
    } catch ( MidiUnavailableException e) {
      System.err.println("MidiUnavailableException caught!");
    }
    
    thirdAvenue.addActionListener(new SongStarter(ThirdAvenue, sequencer));
    
    group.add(thirdAvenue);
    
    menubar.add(music);
    music.add(thirdAvenue);
    
    menubar.add(help);
    help.add(controls);
    help.add(credits);
    menubar.add(backToMenu);
    
    setJMenuBar(menubar);
  }

  //as popup , controls of the game is printed
  private void printControls() {
    StringBuilder sb = new StringBuilder();
    
    sb.append("Left arrow or 'A' button in the keyboard keys move piece left\n");
    sb.append("Right arrow or 'D' button in the keyboard keys move piece right\n");
    sb.append("Down arrow key or 'S' button in the keyboard keys move piece down\n");
    sb.append("Up arrow key or 'W' button in the keyboard keys hard drop piece\n");
    sb.append("Space bar rotates piece\n");
    sb.append("P pauses your game\n\n");
    sb.append("Q gives you are promt whether you want to quit game immediately or not\n\n");
    sb.append("Level up every 5 (five) lines\n");
    sb.append("May the force be with you");
    
    JOptionPane.showMessageDialog(null, sb.toString());
  }
  
  //credits method to print out the names
  private void credit() {
	    StringBuilder sb = new StringBuilder();
	    
	    sb.append("TETFIT v1.0\n\n");
	    sb.append("Producers of the game:\n");
	    sb.append("Mustafa CULBAN\n");
	    sb.append("Irmak AKKUZUOGLU\n");
	    sb.append("Irmak TURKOZ\n");
	    sb.append("Yasin ERDOGDU\n");
	    sb.append("Tibet TIMUR\n\n\n");
	    sb.append("made with love <3 \n");
	    
	    JOptionPane.showMessageDialog(null, sb.toString());
	  }
  

  //pause the game
  private void pause( BoardDisplay bd) {
    if (isGamePaused) {
    	bd.setPause();
      gameTimer.start();
      isGamePaused = false;
    } else {
    	bd.setPause();
      gameTimer.stop();
      isGamePaused = true;
    }
  }
  

  
  // Observer interface's method update. It is called when there is a change.
  @Override
  public void update( Observable observable, Object object) {
    if (object != null) {
      lineCleanedSoFar = (int) object + lineCleanedSoFar;
    
      if (1000 - (lineCleanedSoFar / 5 * 100) > 0) {
        gameTimer.setDelay(1000 - (lineCleanedSoFar / 5 * 100));
      } else {
        gameTimer.setDelay(100);
      }
    }
    
    if (((Board) observable).isGameOver()) {
      gameTimer.stop();
      JOptionPane.showMessageDialog(null, "Let the new game begin again ha ?");
    }
  }
  
  
  //to select a midi song in use of sequencer 
  private class SongStarter implements ActionListener {    
    private  Sequence sequence;
    private  Sequencer sequencer;
    
    //constructor
    public SongStarter( Sequence sequence,  Sequencer sequencer) {
    	this.sequence = sequence;
    	this.sequencer = sequencer;
    }
    
    //now lets start the sequencer for the midi music to play it.
    @Override
    public void actionPerformed( ActionEvent the_e) {
    	sequencer.stop();
      try {
    	  sequencer.setSequence(sequence);
      } catch ( InvalidMidiDataException e) {
        System.err.println("InvalidMidiDataException caught!");
      } 
      sequencer.start();
    }
    
  }
  
  //all the controls pausing game and immediately quitting from game is handled from here. It is key listener
  private  class TetrisKeyListener extends KeyAdapter {
    
    //keylistener listens the board
    protected Board boardd;

    //board display here listener also listens
    protected BoardDisplay boardDisplay;
    
    //constructor
    public TetrisKeyListener( Board boardd,  BoardDisplay boardDisplay) {
      super();
      this.boardd = boardd;
      this.boardDisplay = boardDisplay;
    }
    
    //now lets define the controls on the game, pausng game with a button or quiting immediately from the game.
    @Override
    public void keyPressed(KeyEvent e) {
      
      if (!isGamePaused && !isGameOver) {
        if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) {
        	boardd.moveDown();
        } else if (e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_A) {
        	boardd.moveLeft();
        } else if (e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) {
        	boardd.moveRight();
        } else if (e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_W) {
        	boardd.toTheBottom();
        } else if (e.getKeyCode() == KeyEvent.VK_SPACE ) {
        	boardd.rotate();
        }
      }
      if (e.getKeyCode() == KeyEvent.VK_P) {
        pause(boardDisplay);
      }
      if (e.getKeyCode() == KeyEvent.VK_Q) {
    	  pause(boardDisplay);
    	  int selectedOption = JOptionPane.showConfirmDialog(null, 
                  "U wanno really close this superb game?", 
                  "the chose your side", 
                  JOptionPane.YES_NO_OPTION); 
    	  if (selectedOption == JOptionPane.YES_OPTION) {
    		  sequencer.stop();
    		  sequencer.close();
    		  dispose();
    	  }
    	  else{
    		  pause(boardDisplay);
    	  }
        }
    }
  }

}
