
package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import java.util.Observable;
import java.util.Observer;

import javax.swing.BorderFactory;
import javax.swing.JPanel;


import model.PieceInterface;
import model.AbstractPiece;
import model.Board;

public class NextPieceDisplay extends JPanel implements Observer {
  private static final long serialVersionUID = 3333333;

  // next piece which will be shown in the panel
  private PieceInterface mutableNextPiece;

  //constructor
  public NextPieceDisplay() {
    super();
    setBackground(Color.YELLOW);
    setBorder(BorderFactory.createLineBorder(Color.ORANGE));
    setPreferredSize(new Dimension(50, 80));
  }

  
  //next piece painting
  @Override
  public void paintComponent( Graphics graph) {
    super.paintComponent(graph);
    Graphics2D g2d = (Graphics2D) graph;
    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    
     int[][] pieceCoordinates = ((AbstractPiece) mutableNextPiece).getRotation();
    
    for (int i = 0; i < pieceCoordinates.length; i++) {
       Shape s = new Rectangle2D.Double(pieceCoordinates[i][0] * 10, 80 + pieceCoordinates[i][1] * 10 - 60, 10, 10);
      g2d.setPaint(((AbstractPiece) mutableNextPiece).getBlock().getColor());
      g2d.fill(s);
      g2d.setPaint(Color.BLACK);
      g2d.draw(s);
    }
  }
  

  //Observer interface's method. it is used when it is required.
  @Override
  public void update( Observable the_o,  Object the_arg) {
    mutableNextPiece = ((Board) the_o).getNextPiece();
    
    if (!((Board) the_o).isGameOver()) {
      repaint();
    }
  }

}
