package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import java.util.LinkedList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

import model.PieceInterface;
import model.AbstractPiece;
import model.Board;
import model.Block;


public class BoardDisplay extends JPanel implements Observer {

  private static final long serialVersionUID = -111111;

  // blocks have been put to the board
  protected List<Block[]> blocksHaveBeenPut;
  
  // current controllable pieces
  protected PieceInterface currPiece;

  // is game paused or not ,is game over or not
  protected boolean onPause, is_Game_Over;

  //constructor
  
  public BoardDisplay() {
    super();
    onPause = false;
    setBackground(Color.darkGray);
    setBorder(BorderFactory.createLineBorder(Color.WHITE));
    setPreferredSize(new Dimension( 250,550));
  }
  
  @Override
  public void addNotify() {
    super.addNotify();
    requestFocus();
  }
  
  @Override
  public void paintComponent( Graphics graph) {
    super.paintComponent(graph);
    Graphics2D g2d = (Graphics2D) graph;
    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    
     int[][] pieceCoordinates = ((AbstractPiece) currPiece).getBoardCoordinates();
    
    for (int i = 0; i < pieceCoordinates.length; i++) {
       Shape s = new Rectangle2D.Double(pieceCoordinates[i][0] * 25,550 - pieceCoordinates[i][1]* 25 - 25, 25, 25);
      if (is_Game_Over) {
        g2d.setPaint(Color.GRAY);
      } else {
        g2d.setPaint(((AbstractPiece) currPiece).getBlock().getColor());
      }
      g2d.fill(s);
      g2d.setPaint(Color.BLACK);
      g2d.draw(s);
    }
    
    for (int i = 0; i < blocksHaveBeenPut.size(); i++) {
      for (int j = 0; j < blocksHaveBeenPut.get(i).length; j++) {
        if (blocksHaveBeenPut.get(i)[j] != Block.EMPTY) {
           Shape s = new Rectangle2D.Double(j * 25, 
        		  550 - i * 25 
                                                 - 25, 25, 25);

          if (is_Game_Over) {
            g2d.setPaint(Color.GRAY);
          } else {
            g2d.setPaint(blocksHaveBeenPut.get(i)[j].getColor());
          }
          g2d.fill(s);
          g2d.setPaint(Color.RED);
          g2d.draw(s);
        }
      }
    }
    
    if (onPause) {
       Shape s = new Rectangle2D.Double(0, 0, (int) (25 * 10), (int) (25 * 22));
      g2d.setPaint(Color.darkGray);
      g2d.fill(s);
    }
  }
 
  
  public boolean isPaused() {
    return onPause;
  }
  

  
  public void setPause() {
    if (onPause) {
      onPause = false;
    } else {
      onPause = true;
    }
    repaint();
  }
  
  
  public boolean isGameOver() {
    return is_Game_Over;
  }
  
  
  public void setGameOver() {
    if (is_Game_Over) {
      is_Game_Over = false;
    } else {
      is_Game_Over = true;
    }
    repaint();
  }

  
  @Override
  public void update( Observable the_o,  Object the_arg) {
    currPiece = ((Board) the_o).getCurrentPiece();
    blocksHaveBeenPut = (LinkedList<Block[]>) ((Board) the_o).getFrozenBlocks();
    
    if (((Board) the_o).isGameOver()) {
      is_Game_Over = true;
    }
    
    repaint();
  }

}
