
package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.Observable;
import java.util.Observer;

import javax.swing.BorderFactory;
import javax.swing.JPanel;


public class InfoDisplay extends JPanel implements Observer {
  
  
  private static final long serialVersionUID = 222222222;

  //1-current level of the player. on each level update, blocks speed will increase 100ms per block
  //2-score of the player, currently. Basically score will be calculated by squaring the accomplished lines in the game
  //3-player cleared this many line
  			// 1st			2nd				3rd
  protected int currentLevel, currentScore, linesSoFar;

 
  //constructor 
  public InfoDisplay() {
    super();
    setPreferredSize(new Dimension(150, 100));
    setBorder(BorderFactory.createLineBorder(Color.WHITE));
    setBackground(Color.GRAY);
    currentLevel = 1;
    currentScore = 0;
  }


  //reset to the default settings
  public void reset() {
	    linesSoFar = 0;
	    currentLevel = 1;
	    currentScore = 0;
	    repaint();
	  }
  
  //painting
  @Override
  public void paintComponent( Graphics the_graphics) {
    super.paintComponent(the_graphics);
     Graphics2D g2d = (Graphics2D) the_graphics;
    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    g2d.setPaint(Color.WHITE);
    
    g2d.drawString("Currently Level: " + currentLevel, 25, 25);
    g2d.drawString("You cleaned: " + linesSoFar + " line"+((linesSoFar == 0 || linesSoFar == 1)?"":"s"), 25, 50);
    g2d.drawString("Currently Score: " + currentScore, 25, 75);
  }

  @Override
  public void update( Observable the_o,  Object the_arg) {
    if (the_arg != null) {
      linesSoFar = linesSoFar + (int) the_arg;
      currentLevel = linesSoFar / 10 + 1;
      currentScore = currentScore + ((int) the_arg * (int) the_arg);
      repaint();
    }
  }
  

}
