package model;

import java.awt.Color;

public enum Block {
  EMPTY(" ", Color.BLACK), IBlock("I", PieceInterface.IColor), JBlock("J", PieceInterface.JColor), LBlock("L", PieceInterface.LColor), 
  OBlock("O", PieceInterface.OColor), SBlock("S", PieceInterface.SColor), ZBlock("Z", PieceInterface.ZColor), TBlock("T", PieceInterface.TColor);
  // character which are one of the pieces.
  protected String character;
  protected Color charColor;
  
  // Constructor
  private Block(final String character, final Color charColor) {
	  this.character = character;
	  this.charColor = charColor;
  }

  public Color getColor() {
    return charColor;
  }

  @Override
  public String toString() {
    return character;
  }
}
