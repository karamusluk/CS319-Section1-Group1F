package model;

public class LPiece extends AbstractPiece {

  private static int[][][] MY_ROTATIONS = {{{2, 0}, {2, 1}, {2, 2}, {3, 2}},
                                                 {{1, 1}, {2, 1}, {3, 0}, {3, 1}},
                                                 {{1, 0}, {2, 0}, {2, 1}, {2, 2}},
                                                 {{1, 1}, {1, 2}, {2, 1}, {3, 1}}};

  public LPiece( int x,  int y) {
	  super( Block.LBlock, x, y, MY_ROTATIONS);
  }
}
