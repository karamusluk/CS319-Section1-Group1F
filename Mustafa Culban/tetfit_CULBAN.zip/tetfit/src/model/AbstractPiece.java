package model;

public abstract class AbstractPiece implements PieceInterface, Cloneable {

 
  protected int curr_X, curr_Y , curr_ROTATIONS;
  protected int[][][] ROTATIONS;
 
  protected  Block curr_BLOCK;

  protected AbstractPiece( Block block, int x, int y, int[][][] rotations) {
    ROTATIONS = rotations.clone();
    curr_ROTATIONS = 0;
    curr_X = x;
    curr_Y = y;
    curr_BLOCK = block;
  }


  @Override
  public  void moveLeft() {
    curr_X--;
  }


  @Override
  public  void moveRight() {
    curr_X++;
  }


  @Override
  public  void toTheBottom() {
    curr_Y--;
  }


  @Override
  public  void rotate() {
    if (ROTATIONS.length > 1) {
      if (curr_ROTATIONS <= 0) {
        curr_ROTATIONS = ROTATIONS.length - ((Math.abs(curr_ROTATIONS - 1)
                              % ROTATIONS.length));
      } else {
        curr_ROTATIONS = (curr_ROTATIONS - 1) % ROTATIONS.length;
      }
    }
  }

  
  public  int[][] getRotation() {
    return ROTATIONS[curr_ROTATIONS].clone();
  }

  @Override
  public  int getX() {
    return curr_X;
  }


  @Override
  public  int getY() {
    return curr_Y;
  }


  public  int[][] getBoardCoordinates() {
     int[][] result = new int[4][2];

    for (int i = 0; i < 4; i++) {
      result[i][0] = ROTATIONS[curr_ROTATIONS][i][1] + curr_X;
      result[i][1] = ROTATIONS[curr_ROTATIONS][i][0] + curr_Y;
    }
    return result;
  }


  public  Block getBlock() {
    return curr_BLOCK;
  }

  @Override
  public PieceInterface clone() throws CloneNotSupportedException {
	  PieceInterface result = (PieceInterface) super.clone();
   
    // clone the ROTATIONS 3D array since arrays are mutable
     int[][][] new_array_3d = new int[ROTATIONS.length][ROTATIONS[0].length][];
    for (int array_2d = 0; array_2d < ROTATIONS.length; array_2d++) {
      for (int array_1d = 0; array_1d < ROTATIONS[0].length; array_1d++) {
        new_array_3d[array_2d][array_1d] = ROTATIONS[array_2d][array_1d].clone();
      }
    }
    ((AbstractPiece) result).ROTATIONS = new_array_3d;
   
   
    return result;
  }


  @Override
  public String toString() {

     int width = width();
     int height = height();
     StringBuilder sb = new StringBuilder();

    // Construct the string by walking through the piece top to bottom, left to
    // right.
    for (int j = height - 1; j >= 0; j--) {
      for (int i = 0; i < width; i++) {
        boolean found = false;
        for (int b = 0; b < 4; b++) {
          if (ROTATIONS[curr_ROTATIONS][b][1] == i
              && ROTATIONS[curr_ROTATIONS][b][0] == j) {
            // There is a block here, so print and move on
            sb.append("[]");
            found = true;
            break;
          }
        }
        if (!found) {
          // None of the 4 are here, so put in empty space
          sb.append("  ");
        }
      }
      // Move to the next line
      sb.append("\n");
    }
    return sb.toString();
  }


  private int width() {
    int result = 0;
    for (int i = 0; i < 4; i++) {
      if (ROTATIONS[curr_ROTATIONS][i][1] > result) {
        result = ROTATIONS[curr_ROTATIONS][i][1];
      }
    }
    return result + 1;
  }


  private int height() {
    int result = 0;
    for (int i = 0; i < 4; i++) {
      if (ROTATIONS[curr_ROTATIONS][i][0] > result) {
        result = ROTATIONS[curr_ROTATIONS][i][0];
      }
    }
    return result + 1;
  }
}
