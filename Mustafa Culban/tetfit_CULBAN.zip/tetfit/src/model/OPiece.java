package model;

public class OPiece extends AbstractPiece {

  private static int[][][] MY_ROTATIONS = {{{3, 0}, {3, 1}, {2, 0}, {2, 1}}};
  
  public OPiece( int x,  int y) {
	  super( Block.OBlock, x, y, MY_ROTATIONS);
  }
}
