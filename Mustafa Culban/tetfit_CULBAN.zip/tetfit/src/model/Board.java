package model;


import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Observable;
import java.util.Random;

public  class Board extends Observable {


  public static Random random = new Random();

  protected int width, height;
  
  private  List<Block[]> blockes;

  private PieceInterface currentPiece;

  protected PieceInterface nextPiece;

  protected List<PieceInterface> pieces;

  protected boolean isOver;


  //constructor
  public Board( int w,
                int h,
                List<PieceInterface> p) {
    super();
    pieces = new ArrayList<>();
    setFreezingBlocks(new LinkedList<Block[]>());
    newGame(w, h, p);
  }

  //default constructor with default customizations
  public Board() {
    this(10, 20, new LinkedList<PieceInterface>());
  }


  //creating new game
  public void newGame( int w,  int h, List<PieceInterface> p) {
    if (w < 5 || h < 5) {
      System.err.println("Cannot instansiated");
    }
    setCurrentPiece(null);
    width = w;
    height = h;
    getFreezingBlocks().clear();
    if (p == null) {
      pieces.clear();
    } else {
      pieces = p;
    }
    setIsOver(false);
    if (pieces == null || pieces.isEmpty()) {
        setNextPiece(randomPiece(width / 2 - 2, height));
      } 
    else {
        setNextPiece(pieces.remove(0));
    }
    setCurrentPiece(getNextPiece());
    if (pieces == null || pieces.isEmpty()) {
        setNextPiece(randomPiece(width / 2 - 2, height));
      } else {
        setNextPiece(pieces.remove(0));
      }
    this.setChanged();
    this.notifyObservers();
  }


  public boolean moveLeft() {
    int[][] blocks = ((AbstractPiece) getCurrentPiece()).getBoardCoordinates();// getting the current position
    boolean isPassable = false;
    int i = 0;
    while(i < blocks.length){
        if (blocks[i][0] == 0 || atTheLocation(blocks[i][0] - 1, blocks[i][1]) != Block.EMPTY) {
      	  isPassable = true;
            break; 
        }
        i++;
    }
   
    if (!isPassable) {
      getCurrentPiece().moveLeft();
      setChanged();
      notifyObservers();
    }
    return (!isPassable);
  }

  
  public boolean moveRight() {
     int[][] blocks = ((AbstractPiece) getCurrentPiece()).getBoardCoordinates();// getting the current position
    boolean isPassable = false;
    int i = 0;
    while(i < blocks.length){
        if (blocks[i][0] == width - 1 || atTheLocation(blocks[i][0] + 1, blocks[i][1]) != Block.EMPTY) {
      	  isPassable = true;
            break;
        }
    	i++;
    }
    if (!isPassable) {
      getCurrentPiece().moveRight();
      this.setChanged();
      this.notifyObservers();
    }
    return (!isPassable);
  }

  public boolean moveDown() {
    int[][] blocks = ((AbstractPiece) getCurrentPiece()).getBoardCoordinates();// getting the current position
    boolean isPassable = false;
    int  i = 0;
    while(i < blocks.length){
        if (blocks[i][1] == 0 || atTheLocation(blocks[i][0], blocks[i][1] - 1) != Block.EMPTY) {
      	  isPassable = true;
          break; 
        }
    	i++;
    }
    if (!isPassable) {
      getCurrentPiece().toTheBottom();
      this.setChanged();
      this.notifyObservers();
    } else {// putting to the board. piece Cannot move anymore
    	
    	int[][] coordinates = ((AbstractPiece) getCurrentPiece()).getBoardCoordinates();

        for (int block = 0; block < coordinates.length; block++) {
           int x = coordinates[block][0];
           int y = coordinates[block][1];

          while (y >= getFreezingBlocks().size()) {
             Block[] new_row = new Block[width];
             int g = 0;
             while (g < width){
            	 new_row[g] = Block.EMPTY;
            	 g++;
             }
            getFreezingBlocks().add(new_row);
          }
           Block[] row = getFreezingBlocks().get(y);
          row[x] = ((AbstractPiece) getCurrentPiece()).getBlock();
        }
        //delete the line
        int linecount = 0; 
        int f = getFreezingBlocks().size() - 1;
        while(f >= 0){
            boolean clear = true;
            Block[] blockie = getFreezingBlocks().get(i);

           for (Block block : blockie) {
             if (block == Block.EMPTY) {
               clear = false;
               break;
             }
           }
           if (clear) {
             getFreezingBlocks().remove(i);
             linecount++; 
           }
        	f--;
        }
        this.setChanged();
        this.notifyObservers(linecount); 
      //end of deletion
        
        
        if (getCurrentPiece().getY() > height - 2) {
          setIsOver(true);
        }
        
        setCurrentPiece(getNextPiece());
        if (pieces == null || pieces.isEmpty()) {
            setNextPiece(randomPiece(width / 2 - 2, height));
          } else {
            setNextPiece(pieces.remove(0));
          }
        
        this.setChanged();
        this.notifyObservers();
        
    }
    return (!isPassable);
  }

  //go to the bottom of the board
  public void toTheBottom() {
    boolean isPassable = true;
    while (isPassable) {
    	isPassable = moveDown();
    }
  }
  
  public boolean rotate() {
    getCurrentPiece().rotate();
    //getting current coordinates
     int[][] blocks = ((AbstractPiece) getCurrentPiece()).getBoardCoordinates();
    boolean isPassable = true;

    for (int[] dimension : blocks) {
      if (dimension[0] >= width || atTheLocation(dimension[0], dimension[1]) != Block.EMPTY) {
    	  int k = 1;
    	  while (k < 4){
    		  getCurrentPiece().rotate();
    		  k++;
    	  }
        
        isPassable = false;
        break;
      }
    }
    if (isPassable) {
      setChanged();
      notifyObservers();
    }
    return isPassable;
  }


  //bring the blocks on the specified place
  protected Block atTheLocation( int x,  int y) {
    Block result = null; 
    if (x < width && x >= 0 && y >= 0) {
      
      result = Block.EMPTY;
      if (y < getFreezingBlocks().size()) {
        result = getFreezingBlocks().get(y)[x];
      }
    }
    return result;
  }


  //creates randomly chosen piece
  protected PieceInterface randomPiece( int x,  int y) {
     Block[] blocks = Block.values();
    PieceInterface result;

    switch (blocks[random.nextInt(blocks.length)]) {
      case IBlock:
        result = new IPiece(x, y);
        break;

      case OBlock:
        result = new OPiece(x, y);
        break;
        
      case SBlock:
        result = new SPiece(x, y);
        break;
        
      case JBlock:
        result = new JPiece(x, y);
        break;

      case LBlock:
        result = new LPiece(x, y);
        break;

      case TBlock:
        result = new TPiece(x, y);
        break;

      case ZBlock:
        result = new ZPiece(x, y);
        break;

      default: 
        result = randomPiece(x, y);
        break;
    }
    return result;
  }

	public PieceInterface getNextPiece() {
		return nextPiece;
	}
	
	public void setNextPiece(PieceInterface nextPiece) {
		this.nextPiece = nextPiece;
	}
	
	public boolean getIsOver() {
		return isOver;
	}
	
	public void setIsOver(boolean isOver) {
		this.isOver = isOver;
	}
	
	public List<Block[]> getFreezingBlocks() {
		return blockes;
	}
	
	public void setFreezingBlocks(List<Block[]> blockes) {
		this.blockes = blockes;
	}
	
	public PieceInterface getCurrentPiece() {
		return currentPiece;
	}
	
	public void setCurrentPiece(PieceInterface currentPiece) {
		this.currentPiece = currentPiece;
	}


}

