package model;

import java.awt.Color;

public interface PieceInterface {

  // Color assignments of the objects
  Color IColor = Color.YELLOW;
  Color JColor = Color.PINK;
  Color LColor = Color.CYAN;
  Color SColor = Color.RED;
  Color ZColor = Color.BLUE;
  Color OColor = Color.YELLOW;
  Color TColor = Color.ORANGE;

  // Default methods definitions in interface . 
  void moveLeft();

  void moveRight();

  void toTheBottom();

  void rotate();

  int getX();

  int getY();
}
