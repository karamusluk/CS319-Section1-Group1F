package model;

public class TPiece extends AbstractPiece {

  private static int[][][] MY_ROTATIONS = {{{2, 0}, {2, 1}, {2, 2}, {3, 1}},
                                                 {{1, 1}, {2, 0}, {2, 1}, {3, 1}},
                                                 {{1, 1}, {2, 0}, {2, 1}, {2, 2}},
                                                 {{1, 1}, {2, 1}, {2, 2}, {3, 1}}};

  public TPiece( int x,  int y) {
	  super( Block.TBlock, x, y, MY_ROTATIONS);
  }
}
