import java.util.Arrays;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Comparator;
import java.io.BufferedWriter;
import java.io.FileWriter;


public class TFLogic {

	
	public static int explosion(boolean[][] bmap){
		int a = -1;
		for(int i = 0; i < 4; i++){
			boolean row = false;
			int j = 0;
			while( j< 4 && !row){
				if(!bmap[i][j]){
					j++;
					break;
				}
				if(bmap[i][j] && j == 3){
					row = true;
					break;}
				j++;
			}
			System.out.println(row);
			if(row){
			a = i;
			System.out.println(a);
			break;}
		}
		return a;
	}
	
	public static void readScores (String csvFile){
        String[][] scores = new String[1000][2];
        String line= "";
        int length = 0;
        int index = -1;
        try (BufferedReader bufferer = new BufferedReader(new FileReader(csvFile))) {
        	
        	 
            while ((line = bufferer.readLine()) != null) {
            	index++;
                String[] score = line.split(",");
                
               
                scores[index][0] = score[0];
                //System.out.println(score[1]);
                scores[index][1] = score[1];
                

                
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        //System.out.println(index);
        String[][] scoreTable = new String[index+1][2];
        for(int i = 0; i <= index; i++){
        	scoreTable[i][0] = scores[i][0];
        	scoreTable[i][1] = scores[i][1];
        }
        Arrays.sort(scoreTable, new Comparator<String[]>() {
            @Override
            public int compare(final String[] x, final String[] y) {
                final String xs = x[1];
                final String ys = y[1];
                return xs.compareTo(ys);
                
            }
            

        });
        int ind = ( Math.min(4, index));
        
        for(int i = ind; i >= 0; i--){
        	System.out.println(scoreTable[i][0] + "    " + scoreTable[i][1]);
        }
      }	
	
	public static void writeScores (String csvFile, String newscore, String name) throws IOException{
		while ( newscore.length() < 7)
			newscore = "0" + newscore;
		BufferedWriter out = null;
		try  
		{
		    FileWriter stream = new FileWriter(csvFile, true); //true tells to append data.
		    out = new BufferedWriter(stream);
		    out.write( System.lineSeparator()  + name +", "+newscore);
		}
		catch (IOException er)
		{
		    System.err.println("Error: " + er.getMessage());
		}
		finally
		{
		    if(out != null) {
		        out.close();
		    }
		}
	}
	
	public static void main(String[] args) throws IOException {
		writeScores("score.txt", "98230", "pufi");
		readScores("score.txt");
		}
	
	
}
