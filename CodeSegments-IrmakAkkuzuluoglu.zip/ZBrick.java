
public class ZBrick extends Brick {
	 /**
	   * The x and y-coordinates for all rotations of a ZPiece.
	   */
	  private static final int[][][] ROTATIONS = {{{2, 1}, {2, 2}, {3, 0}, {3, 1}},
	                                                 {{1, 0}, {2, 0}, {2, 1}, {3, 1}},
	                                                 {{1, 1}, {1, 2}, {2, 0}, {2, 1}},
	                                                 {{1, 1}, {2, 1}, {2, 2}, {3, 2}}};

}
