
public class SBrick extends Brick {
	 /**
	   * The x and y-coordinates for all rotations of a SPiece.
	   */
	  private static final int[][][] ROTATIONS = {{{2, 0}, {2, 1}, {3, 1}, {3, 2}},
	                                                 {{1, 1}, {2, 0}, {2, 1}, {3, 0}},
	                                                 {{1, 0}, {1, 1}, {2, 1}, {2, 2}},
	                                                 {{1, 2}, {2, 1}, {2, 2}, {3, 1}}};

}
