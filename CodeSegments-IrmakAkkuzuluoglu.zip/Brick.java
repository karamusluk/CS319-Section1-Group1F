
public class Brick {

	  public static final int SquareNo = 4;

	  /** The x coordinate of this Piece. */
	  public int xCoor = 0;

	  /** The y coordinate of this Piece. */
	  public int yCoor = 0;

	  /** The rotational states of this Piece. */
	  public int[][][] rotations = new int[4][4][4];

	  /** The index of the current rotational state of this Piece. */
	  public int currentRot = 0;

	  public final void moveLeft() {
	    xCoor--;
	  }

	  public final void moveRight() {
	    xCoor++;
	  }

	  public final void moveDown() {
	    yCoor--;
	  }

	  public final void rotate() {
	/**    if (my_rotations.length > 1) {
	      if (my_current_rotation <= 0) {
	        my_current_rotation = my_rotations.length - ((Math.abs(my_current_rotation - 1)
	                              % my_rotations.length));
	      } else {
	        my_current_rotation = (my_current_rotation - 1) % my_rotations.length;
	      }
	    } */
	  }

	  /**
	   * Returns the coordinates of this piece's current rotation.
	   * 
	   * @return The coordinates of this piece's current rotation.
	   */
	/**  public final int[][] getRotation() {
	    return my_rotations[my_current_rotation].clone();
	  } */

	 
	  public final int getX() {
	    return xCoor;
	  }

	  public final int getY() {
	    return yCoor;
	  }

	  /**	
	  public final int[][] getBoardCoordinates() {
	    final int[][] result = new int[BLOCKS][2];

	    for (int i = 0; i < BLOCKS; i++) {
	      result[i][0] = my_rotations[my_current_rotation][i][1] + xCoor;
	      result[i][1] = my_rotations[my_current_rotation][i][0] + yCoor;
	    }
	    return result;
	  }


	 
	  public String toString() {

	    final int width = width();
	    final int height = height();
	    final StringBuilder sb = new StringBuilder();

	    // Construct the string by walking through the piece top to bottom, left to
	    // right.
	    for (int j = height - 1; j >= 0; j--) {
	      for (int i = 0; i < width; i++) {
	        boolean found = false;
	        for (int b = 0; b < BLOCKS; b++) {
	          if (my_rotations[my_current_rotation][b][1] == i
	              && my_rotations[my_current_rotation][b][0] == j) {
	            // There is a block here, so print and move on
	            sb.append("[]");
	            found = true;
	            break;
	          }
	        }
	        if (!found) {
	          // None of the blocks are here, so put in empty space
	          sb.append("  ");
	        }
	      }
	      // Move to the next line
	      sb.append("\n");
	    }
	    return sb.toString();
	  } */

	  /**
	   * Returns the width of this piece.
	   * 
	   * @return The width of this piece
	   */
/**
	  public int width() {
	    int result = 0;
	    for (int i = 0; i < BLOCKS; i++) {
	      if (my_rotations[my_current_rotation][i][1] > result) {
	        result = my_rotations[my_current_rotation][i][1];
	      }
	    }
	    return result + 1;
	  }
*/
	  /**
	   * Returns the height of this piece.
	   * 
	   * @return The height of this piece
	   */
	/**  public int height() {
	    int result = 0;
	    for (int i = 0; i < BLOCKS; i++) {
	      if (my_rotations[my_current_rotation][i][0] > result) {
	        result = my_rotations[my_current_rotation][i][0];
	      }
	    }
	    return result + 1;
	  } */
	  
}
