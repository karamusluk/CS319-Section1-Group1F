
public class OBrick extends Brick {
	/**
	   * The x and y-coordinates for all rotations of a OPiece.
	   */
	  private static final int[][][] ROTATIONS = {{{3, 0}, {3, 1}, {2, 0}, {2, 1}}};

	

}
