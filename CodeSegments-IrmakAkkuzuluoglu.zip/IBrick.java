
public class IBrick extends Brick {
	/**
	   * The x and y-coordinates for all rotations of a IPiece.
	   */
	  private static final int[][][] ROTATIONS = {{{2, 0}, {2, 1}, {2, 2}, {2, 3}},
	                                                 {{0, 1}, {1, 1}, {2, 1}, {3, 1}},
	                                                 {{1, 0}, {1, 1}, {1, 2}, {1, 3}},
	                                                 {{0, 2}, {1, 2}, {2, 2}, {3, 2}}};


}
