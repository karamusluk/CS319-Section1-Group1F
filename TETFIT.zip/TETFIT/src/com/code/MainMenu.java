package com.code;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Created by Irma Chan on 5.5.2017.
 */
public class MainMenu extends JPanel {
    public static void main(String[] args) {
        JFrame frame = new JFrame ("TETFIT");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);

        frame.getContentPane().add(new MainMenuPanel());
        frame.pack();
        frame.setVisible(true);
    }
}
