package com.code;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * Created by Irma Chan on 5.5.2017.
 */
public class newGameMenu extends JPanel {
    public newGameMenu(){
        JPanel panel = new JPanel ();
        panel.setVisible(true);
    }
}
