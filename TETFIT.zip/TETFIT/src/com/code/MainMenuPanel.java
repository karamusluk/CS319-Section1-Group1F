package com.code;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.Buffer;
import java.text.DecimalFormat;

/**
 * Created by Irma Chan on 5.5.2017.
 */
public class MainMenuPanel extends JPanel{
    private JButton newGameButton;
    private JButton loadGameButton;
    private JButton helpButton;
    private JButton highScoreButton;
    private JButton creditButton;
    private JButton exitGameButton;
    private BufferedImage myPicture;

    private final int WIDTH=900, HEIGHT=1000;


    //-----------------------------------------------------------------
    //  Constructor: Sets up the panel and necessary data.
    //-----------------------------------------------------------------
    public MainMenuPanel()
    {
        setPreferredSize (new Dimension(WIDTH, HEIGHT));
        setBackground (Color.yellow);
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (ClassNotFoundException ex) {
                } catch (InstantiationException ex) {
                } catch (IllegalAccessException ex) {
                } catch (UnsupportedLookAndFeelException ex) {
                }

            }
        });
        //EXCEPTION CATCHER FOR LOGO'S FILE
        try{
            myPicture= ImageIO.read(new File("images/TETFIT.png"));}
        catch(java.io.IOException e){}


        JLabel logo = new JLabel(new ImageIcon(myPicture));
        JPanel buttons = new JPanel();

        //SET SIZE FOR PANELS AND LABELS
        logo.setPreferredSize(new Dimension(900,300));
        buttons.setPreferredSize(new Dimension(900,650));


        //SET SIZES OF BUTTONS
        newGameButton.setPreferredSize(new Dimension(900,100));
        loadGameButton.setPreferredSize(new Dimension(900,100));
        helpButton.setPreferredSize(new Dimension(900,100));
        highScoreButton.setPreferredSize(new Dimension(900,100));
        creditButton.setPreferredSize(new Dimension(900,100));
        exitGameButton.setPreferredSize(new Dimension(900,100));

        //ACTION LISTENERS LISTED HERE
        newGameButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new newGameMenu();
            }
        });
        loadGameButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

            }
        });

        helpButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

            }
        });

        highScoreButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

            }
        });

        creditButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

            }
        });

        exitGameButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

            }
        });
        //ACTION LISTENERS END HERE


        //ADD BUTTONS TO PANEL NAMED BUTTONS
        buttons.add(newGameButton);
        buttons.add(loadGameButton);
        buttons.add(helpButton);
        buttons.add(highScoreButton);
        buttons.add(creditButton);
        buttons.add(exitGameButton);

        //ADD LOGO
        add(logo);
        //ADD BUTTONS PANEL
        add(buttons);

    }

    public void paintComponent (Graphics page)
    {
        super.paintComponent (page);
        page.setColor (Color.black);
    }


}
