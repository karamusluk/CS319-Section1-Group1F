import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class GameMenu extends JFrame { 
	/**
	 * Author : Ohime
	 */
	
	private static final long serialVersionUID = 1L;
	
	
	JLabel L1;
	
	//THE IMAGE SOURCES ARE INITIALIZED AS BUFFERED IMAGES
	public BufferedImage myBackground;
	
	public BufferedImage myNewGameButton;
	public BufferedImage myCreditsButton;
	public BufferedImage myHighScoreButton;
	public BufferedImage myHelpButton;
	public BufferedImage myOptionsButton;
	//public BufferedImage myExitGameButton; NO NEED FOR AN EXIT BUTTON
	
	public BufferedImage myNewGameButtonClicked;
	public BufferedImage myCreditsButtonClicked;
	public BufferedImage myHighScoreButtonClicked;
	public BufferedImage myHelpButtonClicked;
	public BufferedImage myOptionsButtonClicked;
	
	JButton b1, b2, b3, b4, b5;
	
	//IMAGEICON OBJECTS OF THOSE IMAGE SOURCES
	ImageIcon newGameButton;
	ImageIcon creditsButton;
	ImageIcon highScoreButton;
	ImageIcon helpButton;
	ImageIcon optionsButton;
	
	ImageIcon newGameButtonClicked;
	ImageIcon creditsButtonClicked;
	ImageIcon highScoreButtonClicked;
	ImageIcon helpButtonClicked;
	ImageIcon optionsButtonClicked;

	
	public GameMenu(){
		setTitle("Tetfit v1.0"); //SETS TITLE OF THE APPLICATION
	    setSize(100, 700); //SETS THE SIZE
	    setLocationRelativeTo(null);
	    setDefaultCloseOperation(EXIT_ON_CLOSE); //DEFAULT CLOSE OPERATION
	    setVisible(true); 
	      
	    setLayout(new BorderLayout());

	    //IMAGES ARE TAKEN AS IMAGEICON FROM THE DIRECTORY
	    try {
	    	myBackground = ImageIO.read(new File("images/background.png"));
	    } catch (IOException e) {
			// TODO Auto-generated catch block
	    	e.printStackTrace();
	      }
	    ImageIcon background = new ImageIcon(myBackground);
	    
	    setContentPane(new JLabel(background)); //BACKGROUND CONTENTPANE IS SET
	    
	    try {
	    	myNewGameButton = ImageIO.read(new File("images/new_game_button.png"));
	    } catch (IOException e) {
			// TODO Auto-generated catch block
	    	e.printStackTrace();
	      }
	    newGameButton = new ImageIcon(myNewGameButton);
	    
	    
	    try {
	    	myCreditsButton = ImageIO.read(new File("images/credits_button.png"));
	    } catch (IOException e) {
			// TODO Auto-generated catch block
	    	e.printStackTrace();
	      }
	    creditsButton = new ImageIcon(myCreditsButton);
	    
	    try {
	    	myHighScoreButton = ImageIO.read(new File("images/high_score_button.png"));
	    } catch (IOException e) {
			// TODO Auto-generated catch block
	    	e.printStackTrace();
	      }
	    highScoreButton= new ImageIcon(myHighScoreButton);
	    
	    try {
	    	myHelpButton = ImageIO.read(new File("images/help_button.png"));
	    } catch (IOException e) {
			// TODO Auto-generated catch block
	    	e.printStackTrace();
	      }
	    helpButton= new ImageIcon(myHelpButton);
	    
	    try {
	    	myOptionsButton = ImageIO.read(new File("images/options_button.png"));
	    } catch (IOException e) {
			// TODO Auto-generated catch block
	    	e.printStackTrace();
	      }
	    optionsButton= new ImageIcon(myOptionsButton);
	    
	    //DIDN'T TAKE EXIT BUTTON***************************************************
	    /*try {
	    	myExitGameButton = ImageIO.read(new File("images/exit_button.png"));
	    } catch (IOException e) {
			// TODO Auto-generated catch block
	    	e.printStackTrace();
	      }
	    ImageIcon exitGameButton= new ImageIcon(myExitGameButton);*/
	    //**************************************************************************
	    
	    //BACKGROUND IMAGE IS ADDED*************************************************
	    setLayout(new FlowLayout());
	    L1 = new JLabel(); 
	    add(L1); 
	    setSize(1250, 680); //sets the size of the background image
	    //**************************************************************************
	    
	    //BUTTONS CREATED
	  	b1 = new JButton();
		b2 = new JButton();
		b3 = new JButton();
		b4 = new JButton();
		b5 = new JButton();
		//JButton b6 = new JButton(); //THAT EXIT BUTTON
		
		b1.addMouseListener(new ButtonListener());
		//b2.addMouseListener(new ButtonListener());
		//b3.addMouseListener(new ButtonListener());
		//b4.addMouseListener(new ButtonListener());
		//b5.addMouseListener(new ButtonListener());
		
		
		
		//IMAGES ARE ADDED TO BUTTONS BELOW******************************************
		JPanel p1 = new JPanel();
		b1.setIcon(newGameButton);
		b1.setMargin(new Insets(0, 0, 0, 0));
		b1.setBorder(null);
		p1.add(b1);
		
		JPanel p2 = new JPanel();
		b2.setIcon(creditsButton);
		b2.setMargin(new Insets(0, 0, 0, 0));
		b2.setBorder(null);
		p2.add(b2);
	
		JPanel p3 = new JPanel();
		b3.setIcon(highScoreButton);
		b3.setMargin(new Insets(0, 0, 0, 0));
		b3.setBorder(null);
		p3.add(b3);
		
		JPanel p4 = new JPanel();
		b4.setIcon(helpButton);
		b4.setMargin(new Insets(0, 0, 0, 0));
		b4.setBorder(null);
		p4.add(b2);
		
		JPanel p5 = new JPanel();
		b5.setIcon(optionsButton);
		b5.setMargin(new Insets(0, 0, 0, 0));
		b5.setBorder(null);
		p5.add(b5);
		
		//HAHA NO NEED FOR EXIT  WE HAVE "X" ALREADY
		//JPanel p6 = new JPanel();
		//b6.setIcon(exitGameButton);
		//b6.setMargin(new Insets(0, 0, 0, 0));
		//b6.setBorder(null);
		//p6.add(b6);
		
		//*************************************************************************
		
		add(Box.createRigidArea(new Dimension(20,700))); //MADE SPACE FOR THE TITLE
		
		add(b1);
		add(b2);
		add(b3);
		add(b4);
		add(b5);
		//add(b6);
		
		
		//MOUSE_ENTERED IMAGES ARE READ BELOW------------------------------------------------------
		
		try {
	    	myNewGameButtonClicked = ImageIO.read(new File("images"
	    			+ "/new_game_button_clicked.png"));
	    } catch (IOException e) {
			// TODO Auto-generated catch block
	    	e.printStackTrace();
	      }
	    newGameButtonClicked = new ImageIcon(myNewGameButtonClicked);
	    
	    
	    try {
	    	myCreditsButton = ImageIO.read(new File("images/credits_button_clicked.png"));
	    } catch (IOException e) {
			// TODO Auto-generated catch block
	    	e.printStackTrace();
	      }
	    creditsButtonClicked = new ImageIcon(myCreditsButtonClicked);
	    
	    try {
	    	myHighScoreButtonClicked = ImageIO.read(new File("images/high_score_button_clicked.png"));
	    } catch (IOException e) {
			// TODO Auto-generated catch block
	    	e.printStackTrace();
	      }
	    highScoreButtonClicked= new ImageIcon(myHighScoreButtonClicked);
	    
	    try {
	    	myHelpButtonClicked = ImageIO.read(new File("images/help_button_clicked.png"));
	    } catch (IOException e) {
			// TODO Auto-generated catch block
	    	e.printStackTrace();
	      }
	    helpButtonClicked= new ImageIcon(myHelpButtonClicked);
	    
	    try {
	    	myOptionsButtonClicked = ImageIO.read(new File("images/options_button_clicked.png"));
	    } catch (IOException e) {
			// TODO Auto-generated catch block
	    	e.printStackTrace();
	      }
	    optionsButtonClicked= new ImageIcon(myOptionsButtonClicked);	
	  
	}//END OF CONSTRUCTOR
	
	
	//MOUSELISTENERS*************************************************************
	public class ButtonListener implements MouseListener{
		public void mouseEntered(MouseEvent evt){
			b1.setIcon(newGameButtonClicked);
			//b2.setIcon(optionsButtonClicked);
		
		}
		public void mouseExited(MouseEvent evt){
			b1.setIcon(newGameButton);
			//b2.setIcon(optionsButton);
		}
		@Override
		public void mouseClicked(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void mousePressed(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void mouseReleased(MouseEvent arg0) {
			// TODO Auto-generated method stub
			
		}
		
		
	}
	//*****************************************************************************
	

	public static void main(String args[]){

	    new GameMenu(); 

	  } 
	}

